package ecommerce.entity;

public enum ShippingMethod {
	
	Standart, Premium;

}
