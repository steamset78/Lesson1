package ecommerce.entity;

public enum Gender {
	
	Men, Women, Kids;

}
