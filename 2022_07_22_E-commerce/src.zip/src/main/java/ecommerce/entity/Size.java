package ecommerce.entity;

public enum Size {

	S, XS, M, L, XL, XXL, XXXL;
}
